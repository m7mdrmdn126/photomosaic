import cv2 as cv
import numpy as np


BOARD_WIDTH , BOARD_HEIGHT = 940  , 620
IM_WIDTH , IM_HEIGHT = 225 , 150
ROWS,COLUMNS = 300 , 900
CANVAS = np.zeros((ROWS , COLUMNS , 3), dtype="uint8")

BOARD = cv.imread('Resources/photomosaic.jpeg')
IMAGES = [ f'Resources/img{i}.png' for i in range(1,9)]

BOARD = cv.resize(BOARD , (BOARD_WIDTH , BOARD_HEIGHT) , interpolation= cv.INTER_AREA)


def get_images(images) :
    place = [0 , 0]
    for image in images :
        im = cv.imread(image)
        resized_img = cv.resize(im, (IM_WIDTH, IM_HEIGHT), interpolation=cv.INTER_AREA)

        placei = [ 20 + place[0] * IM_WIDTH , 160 +  place[1] * IM_HEIGHT]


        BOARD[placei[1] : placei[1] + IM_HEIGHT , placei[0] : placei[0] + IM_WIDTH] = resized_img
        place[0] += 1
        print(place)

        if place[0] == 4 :
            place = [0 , 1]


get_images(IMAGES)



print(BOARD.shape)
cv.imshow('canvas' , BOARD)
cv.waitKey(0)