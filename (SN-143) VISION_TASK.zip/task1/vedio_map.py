import cv2 as cv 
import numpy as np

MY_VID = cv.VideoCapture('Resources/Endurance.mp4')
SNAPSHOTS = []

ROWS , COLUMNS = 900 , 300
CANVAS = np.zeros((ROWS , COLUMNS , 3) , dtype= "uint8")


def capture():
    while True :
        ret , frame = MY_VID.read() 
        if not ret :
            break

        cv.imshow('video',frame)
        key = cv.waitKey(50)

        if key == ord('t'):
            SNAPSHOTS.append(frame)


    


    MY_VID.release()
    cv.destroyAllWindows()


def make():
    CANVAS[0:900 , 0 : 150] = cv.resize(SNAPSHOTS[0] , (150 , 900))
    CANVAS[0:900 , 150 : 300] = cv.resize(SNAPSHOTS[1] , (150 , 900))

capture()
make()

cv.imshow("image" , CANVAS)
cv.waitKey(0)


